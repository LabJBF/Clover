import SwiftUI

struct AppIconView: View {
    let app: StoreApp
    var size: CGFloat = 64

    var body: some View {
        Group {
            if let url = app.iconURL, !url.absoluteString.contains("example.com") {
                AsyncImage(url: url) { phase in
                    if let image = phase.image {
                        image.resizable().scaledToFill()
                    } else {
                        fallback
                    }
                }
            } else {
                fallback
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.23, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: size * 0.23, style: .continuous)
                .strokeBorder(.white.opacity(0.16), lineWidth: 1)
        }
    }

    private var fallback: some View {
        ZStack {
            LinearGradient(
                colors: [CloverPalette.violet, CloverPalette.blue],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            Image(systemName: "clover.fill")
                .font(.system(size: size * 0.48, weight: .medium))
                .foregroundStyle(.white)
        }
    }
}
