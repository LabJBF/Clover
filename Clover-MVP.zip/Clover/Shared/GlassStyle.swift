import SwiftUI

enum CloverPalette {
    static let violet = Color(red: 0.42, green: 0.34, blue: 0.98)
    static let blue = Color(red: 0.25, green: 0.57, blue: 0.98)
    static let mint = Color(red: 0.28, green: 0.78, blue: 0.68)
}

struct CloverBackground: View {
    var body: some View {
        ZStack {
            Color(uiColor: .systemGroupedBackground)
                .ignoresSafeArea()
            LinearGradient(
                colors: [
                    CloverPalette.violet.opacity(0.12),
                    CloverPalette.blue.opacity(0.07),
                    .clear
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
        }
    }
}

extension View {
    func cloverGlass(cornerRadius: CGFloat = 22) -> some View {
        self
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .strokeBorder(.white.opacity(0.18), lineWidth: 1)
            }
    }
}
