import SwiftUI

@main
struct CloverApp: App {
    @StateObject private var store = CloverStore()

    var body: some Scene {
        WindowGroup {
            RootTabView()
                .environmentObject(store)
                .preferredColorScheme(store.appearance.colorScheme)
        }
    }
}
