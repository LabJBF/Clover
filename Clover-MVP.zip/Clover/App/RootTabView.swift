import SwiftUI

struct RootTabView: View {
    var body: some View {
        TabView {
            DiscoverView()
                .tabItem { Label("Discover", systemImage: "square.grid.2x2.fill") }
            SourcesView()
                .tabItem { Label("Sources", systemImage: "shippingbox.fill") }
            LibraryView()
                .tabItem { Label("Library", systemImage: "square.stack.3d.up.fill") }
            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape.fill") }
        }
        .tint(CloverPalette.violet)
    }
}
