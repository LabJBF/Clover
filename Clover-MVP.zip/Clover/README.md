# Clover

Clover is an early iOS sideloading-store MVP focused on app discovery, JSON repositories, app details, and IPA file management.

## Current MVP
- SwiftUI interface with a Liquid Glass-inspired visual style (uses native materials on iOS 17+).
- Discover tab with search and category filtering.
- Repository management: add, refresh, and remove JSON sources.
- Parses an AltStore-style repository format (`apps` array and `versions`).
- App details with version, developer, description, and download link.
- Imports `.ipa` files from Files into Clover's local Documents folder.
- Settings and local source persistence.
- GitHub Actions workflow that builds the iOS Simulator target without code signing.

## Requirements
- Xcode 16 or later recommended.
- iOS deployment target: 17.0.
- Swift 5.9+.
- Open `Clover.xcodeproj` in Xcode, or push this repository to GitHub and run the workflow.

## Build locally
```bash
xcodebuild -project Clover.xcodeproj \
  -scheme Clover \
  -sdk iphonesimulator \
  -destination 'generic/platform=iOS Simulator' \
  CODE_SIGNING_ALLOWED=NO build
```

## Add a repository
In Clover, open **Sources**, tap **+**, and paste a direct HTTPS URL to a JSON repository. Clover validates the response and stores the URL locally.

The repository should have this general shape:

```json
{
  "name": "Example Source",
  "identifier": "com.example.source",
  "apps": [
    {
      "name": "Example App",
      "bundleIdentifier": "com.example.app",
      "developerName": "Example Developer",
      "subtitle": "A sample app",
      "localizedDescription": "Description of the app.",
      "iconURL": "https://example.com/icon.png",
      "category": "Utilities",
      "versions": [
        {
          "version": "1.0.0",
          "date": "2026-01-01T00:00:00Z",
          "downloadURL": "https://example.com/Example.ipa",
          "size": 1234567,
          "minOSVersion": "17.0"
        }
      ]
    }
  ]
}
```

Clover also includes an optional sample catalog so the first launch is not an empty screen. Sample items are clearly marked as demo entries and are not real downloads.

## Important limitations
- Clover's first version is a catalog and repository manager, not an installer.
- Tapping a download link opens it using the system browser; it does not install the IPA.
- Importing an IPA copies it into Clover's Documents directory and records basic file metadata. This does not sign or install it.
- Arbitrary app installation is constrained by iOS signing, entitlements, and supported installation mechanisms. Future signing/installer integrations must use documented, compatible workflows.
- Repository JSON is untrusted input. Use trusted sources, HTTPS, and verify app publishers before downloading files.

## Project structure
```text
Clover/
├── App/
├── Core/Models/
├── Core/Services/
├── Features/Discover/
├── Features/Sources/
├── Features/Library/
├── Features/Settings/
├── Shared/
└── Resources/
```
