import SwiftUI

struct SourcesView: View {
    @EnvironmentObject private var store: CloverStore
    @State private var showingAddSource = false
    @State private var sourceURL = ""
    @State private var isAdding = false
    @State private var sourceToDelete: RepositoryEntry?

    var body: some View {
        NavigationStack {
            ZStack {
                CloverBackground()
                List {
                    Section {
                        VStack(alignment: .leading, spacing: 8) {
                            Label("Community Sources", systemImage: "shippingbox.fill")
                                .font(.headline)
                            Text("Add an HTTPS JSON repository to bring its apps into Discover.")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 8)
                        .listRowBackground(Color.clear)
                    }

                    Section("Your Sources") {
                        if store.repositories.isEmpty {
                            ContentUnavailableView(
                                "No Sources Yet",
                                systemImage: "shippingbox",
                                description: Text("Tap + to add a compatible JSON repository.")
                            )
                            .listRowBackground(Color.clear)
                        } else {
                            ForEach(store.repositories) { entry in
                                HStack(spacing: 12) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 12).fill(.regularMaterial)
                                        Image(systemName: "shippingbox.fill").foregroundStyle(CloverPalette.violet)
                                    }
                                    .frame(width: 44, height: 44)
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(entry.name).font(.headline)
                                        Text(entry.url.host ?? entry.url.absoluteString)
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                            .lineLimit(1)
                                        if let error = entry.lastError {
                                            Text(error).font(.caption2).foregroundStyle(.red).lineLimit(2)
                                        } else if let date = entry.lastUpdated {
                                            Text("Updated \(date.formatted(date: .abbreviated, time: .shortened))")
                                                .font(.caption2).foregroundStyle(.secondary)
                                        }
                                    }
                                    Spacer()
                                    Button {
                                        Task { await store.refresh(entry) }
                                    } label: {
                                        Image(systemName: "arrow.clockwise")
                                    }
                                    .buttonStyle(.borderless)
                                    .accessibilityLabel("Refresh \(entry.name)")
                                }
                                .padding(.vertical, 4)
                                .swipeActions {
                                    Button(role: .destructive) {
                                        sourceToDelete = entry
                                    } label: {
                                        Label("Delete", systemImage: "trash")
                                    }
                                }
                            }
                        }
                    }
                }
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("Sources")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    if store.isRefreshing { ProgressView() }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showingAddSource = true } label: { Image(systemName: "plus") }
                        .accessibilityLabel("Add source")
                }
            }
            .sheet(isPresented: $showingAddSource) {
                addSourceSheet
                    .presentationDetents([.medium, .large])
                    .presentationDragIndicator(.visible)
            }
            .confirmationDialog("Remove this source?", isPresented: Binding(
                get: { sourceToDelete != nil },
                set: { if !$0 { sourceToDelete = nil } }
            ), titleVisibility: .visible) {
                Button("Remove Source", role: .destructive) {
                    if let entry = sourceToDelete { store.removeRepository(entry) }
                    sourceToDelete = nil
                }
                Button("Cancel", role: .cancel) { sourceToDelete = nil }
            } message: {
                Text("Its apps will no longer be available after the active sources refresh.")
            }
            .alert("Clover", isPresented: Binding(
                get: { store.statusMessage != nil },
                set: { if !$0 { store.statusMessage = nil } }
            )) {
                Button("OK") { store.statusMessage = nil }
            } message: {
                Text(store.statusMessage ?? "")
            }
        }
    }

    private var addSourceSheet: some View {
        NavigationStack {
            Form {
                Section("Repository URL") {
                    TextField("https://example.com/source.json", text: $sourceURL)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.URL)
                        .autocorrectionDisabled()
                }
                Section {
                    Text("Use a trusted HTTPS URL that returns a compatible JSON repository. Clover validates the response before saving it.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Add Source")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showingAddSource = false }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(isAdding ? "Adding…" : "Add") {
                        Task {
                            isAdding = true
                            let success = await store.addRepository(rawURL: sourceURL)
                            isAdding = false
                            if success { showingAddSource = false; sourceURL = "" }
                        }
                    }
                    .disabled(isAdding || sourceURL.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
    }
}
