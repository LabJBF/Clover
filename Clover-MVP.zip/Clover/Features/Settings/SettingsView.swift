import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var store: CloverStore

    var body: some View {
        NavigationStack {
            ZStack {
                CloverBackground()
                List {
                    Section("Appearance") {
                        Picker("Theme", selection: Binding(
                            get: { store.appearance },
                            set: { store.setAppearance($0) }
                        )) {
                            ForEach(AppearanceMode.allCases) { mode in
                                Text(mode.title).tag(mode)
                            }
                        }
                    }
                    Section("Storage") {
                        LabeledContent("Repositories", value: "\(store.repositories.count)")
                        LabeledContent("Imported IPA files", value: "\(store.importedIPAs.count)")
                        LabeledContent("Catalog entries", value: "\(store.apps.count)")
                    }
                    Section("About Clover") {
                        LabeledContent("Version", value: "0.1.0")
                        LabeledContent("Build", value: "MVP")
                        HStack(spacing: 12) {
                            Image(systemName: "clover.fill")
                                .font(.system(size: 30))
                                .foregroundStyle(LinearGradient(colors: [CloverPalette.violet, CloverPalette.blue], startPoint: .topLeading, endPoint: .bottomTrailing))
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Clover").font(.headline)
                                Text("A better home for your app collection.")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                        .padding(.vertical, 5)
                    }
                    Section("Limitations") {
                        Label("Catalog and IPA import only", systemImage: "info.circle")
                        Text("This build does not sign or install applications. Integrations will be added in a later development phase.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("Settings")
        }
    }
}
