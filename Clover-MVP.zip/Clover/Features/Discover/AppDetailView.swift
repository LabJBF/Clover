import SwiftUI

struct AppDetailView: View {
    @Environment(\.dismiss) private var dismiss
    let app: StoreApp

    var body: some View {
        NavigationStack {
            ZStack {
                CloverBackground()
                ScrollView {
                    VStack(alignment: .leading, spacing: 22) {
                        HStack(spacing: 16) {
                            AppIconView(app: app, size: 92)
                            VStack(alignment: .leading, spacing: 6) {
                                Text(app.name).font(.title2.bold())
                                Text(app.displayDeveloper).foregroundStyle(.secondary)
                                Text(app.displaySubtitle).font(.subheadline)
                            }
                            Spacer(minLength: 0)
                        }
                        .padding(18)
                        .cloverGlass(cornerRadius: 26)

                        if let version = app.latestVersion {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("VERSION").font(.caption.weight(.bold)).tracking(1.4).foregroundStyle(.secondary)
                                infoRow("Version", value: version.version)
                                infoRow("Minimum iOS", value: version.minOSVersion ?? "Not specified")
                                infoRow("File size", value: version.formattedSize)
                                if let date = version.date { infoRow("Release date", value: date) }
                            }
                            .padding(18)
                            .cloverGlass()
                        }

                        VStack(alignment: .leading, spacing: 10) {
                            Text("About").font(.title3.bold())
                            Text(app.localizedDescription ?? "No description provided by this source.")
                                .foregroundStyle(.secondary)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        .padding(18)
                        .cloverGlass()

                        VStack(alignment: .leading, spacing: 8) {
                            Text("Source").font(.caption.weight(.bold)).tracking(1.2).foregroundStyle(.secondary)
                            Text(app.sourceName ?? "Unknown source")
                            Text(app.bundleIdentifier)
                                .font(.caption.monospaced())
                                .foregroundStyle(.secondary)
                                .textSelection(.enabled)
                        }
                        .padding(18)
                        .cloverGlass()

                        if let url = app.latestVersion?.downloadURL {
                            Link(destination: url) {
                                Label("Open Download Link", systemImage: "arrow.down.to.line")
                                    .font(.headline)
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 15)
                                    .background(LinearGradient(colors: [CloverPalette.violet, CloverPalette.blue], startPoint: .leading, endPoint: .trailing), in: RoundedRectangle(cornerRadius: 18))
                                    .foregroundStyle(.white)
                            }
                            Text("This opens the download URL. Clover does not install or sign the file in this MVP.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        } else {
                            Label("Demo listing — no download available", systemImage: "info.circle")
                                .font(.subheadline.weight(.medium))
                                .frame(maxWidth: .infinity)
                                .padding(15)
                                .cloverGlass()
                        }
                    }
                    .padding(18)
                }
            }
            .navigationTitle("App Details")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }

    private func infoRow(_ title: String, value: String) -> some View {
        HStack {
            Text(title).foregroundStyle(.secondary)
            Spacer()
            Text(value).fontWeight(.semibold).multilineTextAlignment(.trailing)
        }
        .font(.subheadline)
    }
}
