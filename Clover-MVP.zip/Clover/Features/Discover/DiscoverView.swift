import SwiftUI

struct DiscoverView: View {
    @EnvironmentObject private var store: CloverStore
    @State private var searchText = ""
    @State private var selectedCategory = "All"
    @State private var selectedApp: StoreApp?

    private var categories: [String] {
        let values = Set(store.apps.compactMap(\.category))
        return ["All"] + values.sorted()
    }

    private var filteredApps: [StoreApp] {
        store.apps.filter { app in
            let matchesCategory = selectedCategory == "All" || app.category == selectedCategory
            let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
            let matchesSearch = query.isEmpty ||
                app.name.localizedCaseInsensitiveContains(query) ||
                app.displayDeveloper.localizedCaseInsensitiveContains(query) ||
                app.bundleIdentifier.localizedCaseInsensitiveContains(query)
            return matchesCategory && matchesSearch
        }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                CloverBackground()
                ScrollView {
                    VStack(alignment: .leading, spacing: 22) {
                        hero
                        searchField
                        categoryPicker
                        if filteredApps.isEmpty {
                            ContentUnavailableView(
                                "No Apps Found",
                                systemImage: "magnifyingglass",
                                description: Text("Try another search or add a repository in Sources.")
                            )
                            .padding(.top, 24)
                        } else {
                            LazyVGrid(columns: [GridItem(.adaptive(minimum: 155), spacing: 14)], spacing: 14) {
                                ForEach(filteredApps) { app in
                                    Button {
                                        selectedApp = app
                                    } label: {
                                        AppCardView(app: app)
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 12)
                    .padding(.bottom, 28)
                }
            }
            .navigationTitle("Clover")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        Task { await store.refreshAll() }
                    } label: {
                        Image(systemName: store.isRefreshing ? "arrow.triangle.2.circlepath" : "arrow.clockwise")
                    }
                    .disabled(store.isRefreshing)
                    .accessibilityLabel("Refresh repositories")
                }
            }
            .sheet(item: $selectedApp) { app in
                AppDetailView(app: app)
                    .environmentObject(store)
            }
            .alert("Clover", isPresented: Binding(
                get: { store.statusMessage != nil },
                set: { if !$0 { store.statusMessage = nil } }
            )) {
                Button("OK") { store.statusMessage = nil }
            } message: {
                Text(store.statusMessage ?? "")
            }
        }
    }

    private var hero: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                VStack(alignment: .leading, spacing: 5) {
                    Text("YOUR APP UNIVERSE")
                        .font(.caption.weight(.bold))
                        .tracking(1.8)
                        .foregroundStyle(CloverPalette.violet)
                    Text("Discover something\nextraordinary.")
                        .font(.system(size: 31, weight: .bold, design: .rounded))
                        .fixedSize(horizontal: false, vertical: true)
                }
                Spacer(minLength: 0)
                Image(systemName: "clover.fill")
                    .font(.system(size: 43, weight: .medium))
                    .foregroundStyle(LinearGradient(colors: [CloverPalette.violet, CloverPalette.blue], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .rotationEffect(.degrees(-12))
            }
            Text("A curated home for apps, tools and community sources.")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .padding(20)
        .frame(maxWidth: .infinity, alignment: .leading)
        .cloverGlass(cornerRadius: 28)
    }

    private var searchField: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
            TextField("Search apps or developers", text: $searchText)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
        }
        .padding(.horizontal, 15)
        .padding(.vertical, 13)
        .cloverGlass(cornerRadius: 17)
    }

    private var categoryPicker: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(categories, id: \.self) { category in
                    Button {
                        withAnimation(.snappy(duration: 0.2)) { selectedCategory = category }
                    } label: {
                        Text(category)
                            .font(.subheadline.weight(.semibold))
                            .padding(.horizontal, 15)
                            .padding(.vertical, 9)
                            .background(selectedCategory == category ? CloverPalette.violet : Color.primary.opacity(0.05), in: Capsule())
                            .foregroundStyle(selectedCategory == category ? .white : .primary)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}

private struct AppCardView: View {
    let app: StoreApp

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top) {
                AppIconView(app: app, size: 62)
                Spacer()
                Image(systemName: "arrow.down.circle")
                    .font(.title3)
                    .foregroundStyle(.secondary)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(app.name)
                    .font(.headline)
                    .lineLimit(2)
                    .multilineTextAlignment(.leading)
                Text(app.displaySubtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                Text(app.displayDeveloper)
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
                    .lineLimit(1)
            }
            Spacer(minLength: 0)
            HStack {
                Text(app.latestVersion?.version.map { "v\($0)" } ?? "Catalog")
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(CloverPalette.violet)
                Spacer()
                if app.sourceName == "Clover Demo Catalog" {
                    Text("DEMO")
                        .font(.system(size: 9, weight: .bold))
                        .tracking(0.7)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, minHeight: 190, alignment: .leading)
        .cloverGlass(cornerRadius: 22)
        .contentShape(RoundedRectangle(cornerRadius: 22))
    }
}
