import SwiftUI
import UniformTypeIdentifiers

struct LibraryView: View {
    @EnvironmentObject private var store: CloverStore
    @State private var showingImporter = false
    @State private var itemToDelete: ImportedIPA?

    var body: some View {
        NavigationStack {
            ZStack {
                CloverBackground()
                ScrollView {
                    VStack(alignment: .leading, spacing: 18) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Your files, in one place.")
                                .font(.title2.bold())
                            Text("Import IPA files from Files. Clover stores a local copy and basic metadata; signing and installation are not part of this MVP.")
                                .foregroundStyle(.secondary)
                                .font(.subheadline)
                        }
                        .padding(20)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .cloverGlass(cornerRadius: 24)

                        Button { showingImporter = true } label: {
                            Label("Import IPA File", systemImage: "plus.circle.fill")
                                .font(.headline)
                                .frame(maxWidth: .infinity)
                                .padding(16)
                                .background(LinearGradient(colors: [CloverPalette.violet, CloverPalette.blue], startPoint: .leading, endPoint: .trailing), in: RoundedRectangle(cornerRadius: 18))
                                .foregroundStyle(.white)
                        }

                        if store.importedIPAs.isEmpty {
                            ContentUnavailableView(
                                "No Imported Files",
                                systemImage: "doc.zipper",
                                description: Text("Your imported IPA files will appear here.")
                            )
                            .padding(.top, 18)
                        } else {
                            ForEach(store.importedIPAs) { item in
                                HStack(spacing: 13) {
                                    Image(systemName: "doc.zipper")
                                        .font(.title2)
                                        .foregroundStyle(CloverPalette.violet)
                                        .frame(width: 48, height: 48)
                                        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 14))
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(item.filename).font(.headline).lineLimit(2)
                                        Text(ByteCountFormatter.string(fromByteCount: item.fileSize, countStyle: .file))
                                            .font(.caption).foregroundStyle(.secondary)
                                        Text(item.importedAt.formatted(date: .abbreviated, time: .shortened))
                                            .font(.caption2).foregroundStyle(.tertiary)
                                    }
                                    Spacer()
                                    Button(role: .destructive) { itemToDelete = item } label: {
                                        Image(systemName: "trash")
                                    }
                                    .buttonStyle(.borderless)
                                }
                                .padding(14)
                                .cloverGlass()
                            }
                        }
                    }
                    .padding(18)
                }
            }
            .navigationTitle("Library")
            .fileImporter(isPresented: $showingImporter, allowedContentTypes: [UTType(filenameExtension: "ipa") ?? .data], allowsMultipleSelection: false) { result in
                switch result {
                case .success(let urls):
                    if let url = urls.first { store.importIPA(from: url) }
                case .failure(let error):
                    store.statusMessage = error.localizedDescription
                }
            }
            .confirmationDialog("Delete imported file?", isPresented: Binding(
                get: { itemToDelete != nil },
                set: { if !$0 { itemToDelete = nil } }
            ), titleVisibility: .visible) {
                Button("Delete File", role: .destructive) {
                    if let item = itemToDelete { store.deleteIPA(item) }
                    itemToDelete = nil
                }
                Button("Cancel", role: .cancel) { itemToDelete = nil }
            }
            .alert("Clover", isPresented: Binding(
                get: { store.statusMessage != nil },
                set: { if !$0 { store.statusMessage = nil } }
            )) {
                Button("OK") { store.statusMessage = nil }
            } message: {
                Text(store.statusMessage ?? "")
            }
        }
    }
}
