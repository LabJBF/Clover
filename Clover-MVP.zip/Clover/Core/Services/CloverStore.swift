import Foundation
import SwiftUI

@MainActor
final class CloverStore: ObservableObject {
    @Published private(set) var repositories: [RepositoryEntry] = []
    @Published private(set) var apps: [StoreApp] = SampleCatalog.apps
    @Published private(set) var importedIPAs: [ImportedIPA] = []
    @Published var appearance: AppearanceMode = .system
    @Published var isRefreshing = false
    @Published var statusMessage: String?

    private let repositoryService = RepositoryService()
    private let ipaService = IPAFileService()
    private let defaults = UserDefaults.standard

    private let repositoriesKey = "clover.repositories.v1"
    private let importedKey = "clover.importedIPAs.v1"
    private let appearanceKey = "clover.appearance.v1"

    init() {
        loadLocalState()
    }

    func addRepository(rawURL: String) async -> Bool {
        let trimmed = rawURL.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: trimmed), url.scheme?.lowercased() == "https" else {
            statusMessage = "Enter a valid HTTPS URL."
            return false
        }
        guard !repositories.contains(where: { $0.url == url }) else {
            statusMessage = "That source is already added."
            return false
        }

        do {
            let repository = try await repositoryService.fetch(from: url)
            let entry = RepositoryEntry(
                url: url,
                name: repository.name,
                identifier: repository.identifier,
                lastUpdated: Date(),
                lastError: nil
            )
            repositories.append(entry)
            merge(repository)
            saveRepositories()
            statusMessage = "Added \(repository.name)."
            return true
        } catch {
            statusMessage = error.localizedDescription
            return false
        }
    }

    func refresh(_ entry: RepositoryEntry) async {
        do {
            let repository = try await repositoryService.fetch(from: entry.url)
            if let index = repositories.firstIndex(where: { $0.id == entry.id }) {
                repositories[index].name = repository.name
                repositories[index].identifier = repository.identifier
                repositories[index].lastUpdated = Date()
                repositories[index].lastError = nil
            }
            merge(repository)
            saveRepositories()
            statusMessage = "Updated \(repository.name)."
        } catch {
            if let index = repositories.firstIndex(where: { $0.id == entry.id }) {
                repositories[index].lastError = error.localizedDescription
            }
            saveRepositories()
            statusMessage = error.localizedDescription
        }
    }

    func refreshAll() async {
        isRefreshing = true
        defer { isRefreshing = false }
        for repository in repositories {
            await refresh(repository)
        }
    }

    func removeRepository(_ entry: RepositoryEntry) {
        repositories.removeAll { $0.id == entry.id }
        // Keep apps from remaining sources; reset to demo catalog then merge active sources.
        apps = SampleCatalog.apps
        saveRepositories()
        Task { await refreshAll() }
        statusMessage = "Removed \(entry.name)."
    }

    func importIPA(from url: URL) {
        do {
            let item = try ipaService.importIPA(from: url)
            importedIPAs.insert(item, at: 0)
            saveImported()
            statusMessage = "Imported \(item.filename)."
        } catch {
            statusMessage = error.localizedDescription
        }
    }

    func deleteIPA(_ item: ImportedIPA) {
        do {
            try ipaService.removeIPA(item)
            importedIPAs.removeAll { $0.id == item.id }
            saveImported()
            statusMessage = "Removed \(item.filename)."
        } catch {
            statusMessage = error.localizedDescription
        }
    }

    func setAppearance(_ mode: AppearanceMode) {
        appearance = mode
        defaults.set(mode.rawValue, forKey: appearanceKey)
    }

    private func merge(_ repository: AppRepository) {
        let incoming = repository.apps.map { $0.attaching(sourceName: repository.name) }
        var result = apps
        for app in incoming {
            if let index = result.firstIndex(where: { $0.bundleIdentifier == app.bundleIdentifier }) {
                result[index] = app
            } else {
                result.append(app)
            }
        }
        apps = result
    }

    private func loadLocalState() {
        if let data = defaults.data(forKey: repositoriesKey),
           let saved = try? JSONDecoder().decode([RepositoryEntry].self, from: data) {
            repositories = saved
        }
        if let data = defaults.data(forKey: importedKey),
           let saved = try? JSONDecoder().decode([ImportedIPA].self, from: data) {
            importedIPAs = saved
        }
        if let raw = defaults.string(forKey: appearanceKey),
           let saved = AppearanceMode(rawValue: raw) {
            appearance = saved
        }

        // Re-fetch saved sources when the app starts. Demo items remain available offline.
        if !repositories.isEmpty {
            Task { await refreshAll() }
        }
    }

    private func saveRepositories() {
        guard let data = try? JSONEncoder().encode(repositories) else { return }
        defaults.set(data, forKey: repositoriesKey)
    }

    private func saveImported() {
        guard let data = try? JSONEncoder().encode(importedIPAs) else { return }
        defaults.set(data, forKey: importedKey)
    }
}
