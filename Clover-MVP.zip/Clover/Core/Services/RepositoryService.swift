import Foundation

enum RepositoryError: LocalizedError {
    case invalidResponse
    case badStatus(Int)
    case invalidURL
    case emptyRepository

    var errorDescription: String? {
        switch self {
        case .invalidResponse: "The server returned an invalid response."
        case .badStatus(let code): "The server returned HTTP \(code)."
        case .invalidURL: "Enter a valid HTTPS repository URL."
        case .emptyRepository: "The JSON file did not contain an app repository."
        }
    }
}

struct RepositoryService {
    func fetch(from url: URL) async throws -> AppRepository {
        guard url.scheme?.lowercased() == "https" else {
            throw RepositoryError.invalidURL
        }

        var request = URLRequest(url: url)
        request.timeoutInterval = 25
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let response = response as? HTTPURLResponse else {
            throw RepositoryError.invalidResponse
        }
        guard (200..<300).contains(response.statusCode) else {
            throw RepositoryError.badStatus(response.statusCode)
        }

        let decoder = JSONDecoder()
        let repository = try decoder.decode(AppRepository.self, from: data)
        guard !repository.apps.isEmpty else {
            throw RepositoryError.emptyRepository
        }
        return repository
    }
}
