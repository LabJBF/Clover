import Foundation

enum IPAFileError: LocalizedError {
    case invalidExtension
    case destinationUnavailable

    var errorDescription: String? {
        switch self {
        case .invalidExtension: "Choose a file with the .ipa extension."
        case .destinationUnavailable: "Clover could not access its local Documents folder."
        }
    }
}

struct IPAFileService {
    func importIPA(from sourceURL: URL) throws -> ImportedIPA {
        guard sourceURL.pathExtension.lowercased() == "ipa" else {
            throw IPAFileError.invalidExtension
        }

        let hasAccess = sourceURL.startAccessingSecurityScopedResource()
        defer {
            if hasAccess { sourceURL.stopAccessingSecurityScopedResource() }
        }

        let fileManager = FileManager.default
        guard let documents = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first else {
            throw IPAFileError.destinationUnavailable
        }

        let ipaFolder = documents.appendingPathComponent("ImportedIPAs", isDirectory: true)
        try fileManager.createDirectory(at: ipaFolder, withIntermediateDirectories: true)

        let safeName = sourceURL.lastPathComponent
        let destination = ipaFolder.appendingPathComponent("\(UUID().uuidString)-\(safeName)")

        try fileManager.copyItem(at: sourceURL, to: destination)
        let attributes = try fileManager.attributesOfItem(atPath: destination.path)
        let size = (attributes[.size] as? NSNumber)?.int64Value ?? 0

        return ImportedIPA(
            filename: safeName,
            localFilename: destination.lastPathComponent,
            fileSize: size
        )
    }

    func removeIPA(_ item: ImportedIPA) throws {
        guard let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            throw IPAFileError.destinationUnavailable
        }
        let url = documents
            .appendingPathComponent("ImportedIPAs", isDirectory: true)
            .appendingPathComponent(item.localFilename)
        if FileManager.default.fileExists(atPath: url.path) {
            try FileManager.default.removeItem(at: url)
        }
    }
}
