import Foundation

struct AppRepository: Codable, Identifiable, Hashable {
    var name: String
    var identifier: String?
    var apps: [StoreApp]

    var id: String { identifier ?? name }

    enum CodingKeys: String, CodingKey {
        case name, identifier, apps
    }
}

struct StoreApp: Codable, Identifiable, Hashable {
    var name: String
    var bundleIdentifier: String
    var developerName: String?
    var subtitle: String?
    var localizedDescription: String?
    var iconURL: URL?
    var tintColor: String?
    var category: String?
    var versions: [AppVersion]?
    var sourceName: String?

    var id: String { bundleIdentifier }
    var latestVersion: AppVersion? { versions?.first }
    var displayDeveloper: String { developerName ?? "Unknown Developer" }
    var displaySubtitle: String { subtitle ?? category ?? "Application" }

    enum CodingKeys: String, CodingKey {
        case name, bundleIdentifier, developerName, subtitle
        case localizedDescription, iconURL, tintColor, category, versions
    }

    func attaching(sourceName: String) -> StoreApp {
        var copy = self
        copy.sourceName = sourceName
        return copy
    }
}

struct AppVersion: Codable, Identifiable, Hashable {
    var version: String
    var date: String?
    var downloadURL: URL?
    var size: Int?
    var minOSVersion: String?
    var versionDescription: String?

    var id: String { version }

    var formattedSize: String {
        guard let size, size > 0 else { return "Unknown size" }
        return ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file)
    }
}

struct RepositoryEntry: Codable, Identifiable, Hashable {
    var url: URL
    var name: String
    var identifier: String?
    var lastUpdated: Date?
    var lastError: String?

    var id: String { url.absoluteString }
}

struct ImportedIPA: Codable, Identifiable, Hashable {
    var id: UUID = UUID()
    var filename: String
    var localFilename: String
    var fileSize: Int64
    var importedAt: Date = Date()
}
