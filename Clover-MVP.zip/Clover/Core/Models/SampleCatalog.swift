import Foundation

enum SampleCatalog {
    static let apps: [StoreApp] = [
        StoreApp(
            name: "Clover Demo Player",
            bundleIdentifier: "com.macclover.demo.player",
            developerName: "Clover Team",
            subtitle: "A sample media utility",
            localizedDescription: "A demonstration listing used to preview Clover's catalog. This is sample metadata, not a real downloadable application.",
            iconURL: URL(string: "https://example.com/clover-player.png"),
            tintColor: "#6D5DFB",
            category: "Utilities",
            versions: [AppVersion(version: "1.0.0", date: nil, downloadURL: nil, size: nil, minOSVersion: "17.0", versionDescription: "Demo listing only.")],
            sourceName: "Clover Demo Catalog"
        ),
        StoreApp(
            name: "Clover Notes Demo",
            bundleIdentifier: "com.macclover.demo.notes",
            developerName: "Clover Team",
            subtitle: "A sample notes app",
            localizedDescription: "Another demonstration listing to show how app cards and detail pages look before you add a real repository.",
            iconURL: URL(string: "https://example.com/clover-notes.png"),
            tintColor: "#1E9E82",
            category: "Productivity",
            versions: [AppVersion(version: "0.9.0", date: nil, downloadURL: nil, size: nil, minOSVersion: "17.0", versionDescription: "Demo listing only.")],
            sourceName: "Clover Demo Catalog"
        ),
        StoreApp(
            name: "Clover Lab Demo",
            bundleIdentifier: "com.macclover.demo.lab",
            developerName: "Clover Team",
            subtitle: "Explore experimental tools",
            localizedDescription: "A sample catalog entry for the development build. It does not provide a download.",
            iconURL: URL(string: "https://example.com/clover-lab.png"),
            tintColor: "#E58C36",
            category: "Developer Tools",
            versions: [AppVersion(version: "0.1.0", date: nil, downloadURL: nil, size: nil, minOSVersion: "17.0", versionDescription: "Demo listing only.")],
            sourceName: "Clover Demo Catalog"
        )
    ]
}
